#!/usr/bin/env node

var $ = require('jquery')(require('jsdom-no-contextify').jsdom().parentWindow);
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
$.support.cors = true;
$.ajaxSettings.xhr = function () {
    return new XMLHttpRequest;
}

var now = (new Date).getTime();
var then = now - (30*60*1000);
var cred = ""
cred="Basic " + new Buffer("EUMAccount:EUMkey").toString('base64');

//console.log(cred)

$.ajax({
	type: 'POST',
    url: 'https://analytics.api.appdynamics.com/v1/events/browserrecord/search',
    headers: {
        "Authorization": cred, 
        "Content-Type": "application/json; charset=utf8",
        "Accept" : "application/json"
    },
    error: function(xhr, textStatus, errorThrown){
        console.log("Ajax result Error"+textStatus);
        console.log(xhr.responseText);
    },
    data:  JSON.stringify({
            size: 2,
            query: { filtered: 
                {
                    filter: { range: { eventTimestamp: { gt: "now-1m"}}}
                }
            },
            aggs : {
                "schools" : {
                    terms : { "field" : "userdata.School", "size" : 300 },     
                    aggs  : {
                        "avgRT" : { 
                            "avg" : { "field" : "metrics.enduserresponsetime" } 
                        }
                    }
                }
            }
        }),  
	success: function(saleitems) {
        //console.log("fin")

        //console.dir(saleitems)
        //console.dir(saleitems.aggregations.schools.buckets)
        //console.dir(saleitems.hits.hits[0]["_source"])
        //console.dir(saleitems.hits.hits[1]["_source"])
        var buckets=saleitems.aggregations.schools.buckets
        for(var i=0; i<buckets.length; i++) {
            console.log("name=Hardware Resources|EUM Metrics|Schools|"+buckets[i].key+"|ART,aggregator=OBSERVATION,value=" + Math.round(buckets[i].avgRT.value))
        }
    }	
});

