#!/bin/bash
node advancedshcoolmetrics.js 
