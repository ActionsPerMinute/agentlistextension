
$(function(){
    var url = document.URL
    if(url.indexOf("APP_SERVICE_ENDPOINT_LIST")>-1 && $('#insertedExportDiv').length == 0 && $('.btMoreActionsFlyout:last .ads-mega-menu-list-item:last').length > 0) {
        $('.btMoreActionsFlyout:last .ads-mega-menu-list-item:last').after('<hr style="width: 100%"><div class="btMenuHeader ads-mega-menu-list-item ng-binding">Report</div><div id="insertedExportDiv" class="ads-mega-menu-list-item ng-binding item-hover insertedExportDiv">Export Grid Data</div>')
        $('[ad-label="Actions"]').click(function() {
            $('.insertedExportDiv:last').click(function () {
                var scope = angular.element($('.ad-grid')).scope();
                var allSEs = scope.serviceEndpointListData.serviceEndpointListEntries;
                var inst = AngularUtil.getADInjector().get("gridExportService");
                var fileDescription = inst.createFileDescription(scope.getString("ms_serviceEndpointsTitle"), [
                    { name: scope.getString("ms_application"), value: scope.applicationName },
                    { name: "Total Number of Service EndPoints", value: String(allSEs.length) },
                    { name: "Number of Service EndPoints in this export (some may have been filtered out)", value: String(scope.itemsShown) }
                    ]);
                inst.exportGridData(scope.gridOptions, "Export Service EndPoint Data", fileDescription, "service_endpoints");
            })
        })
    }
})
