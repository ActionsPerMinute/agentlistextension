chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {//add listener to the url
    //chrome.tabs.executeScript( null, { 
    //    file: "jquery-3.1.1.min.js",
    //    runAt: "document_end"
    //});
   chrome.tabs.executeScript( null, { 
        file: "content.js"
    });
})
